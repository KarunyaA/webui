/*Global Variables Section*/

//Declare your Global Variables inside this block
var product;
var productList=[];
var categoryList=[];
var categoryFilterList=[];
var searchText = "";
/*End of Global Variables*/

//Initial call to populate the Products list the first time the page loads
getProducts();
$(".update").hide();
$("#messageDiv").hide();
$("#formMessage").hide();

// A $(document).ready() block.
$(document).ready(function() {
    drapAndDrop();
	//once submit clicked, validating the fields.
	$("#submit").click(function() {		
		if(validateForm()){
			$("#formMessage").css('background-color', '#d9534f');
			$("#formMessage").find("h5").text("Please Fill all Fields");
			$("#formMessage").show();
			setTimeout(function(){ $("#formMessage").hide() }, 5000);
		}else{			
			createProduct();
		}
	});
	
	$(".update").click(function() {		
		if(validateForm()){
			$("#formMessage").css('background-color', '#d9534f');
			$("#formMessage").find("h5").text("Please Fill all Fields");
			$("#formMessage").show();
			setTimeout(function(){ $("#formMessage").hide() }, 5000);
		}else{
			var id = event.target.id;
			editProduct(id);
		}
	});
    
	//closing the delete confirmation pop-up when user clicks cancel button 
	$("#cancel").on('click', function(){
		var modal = document.getElementById('myModal');
		modal.style.display = "none";
		$("#myModal #remove").removeAttr('item');
	});
	
	//once the remove button clicked by user, closing the pop-up and invoking the delete call.
	$("#remove").on('click', function(){
		var modal = document.getElementById('myModal');
		modal.style.display = "none";
		var productId = $("#remove").attr("item");
		$("#myModal #remove").removeAttr('item');
		removeProduct(productId);	
	});
	
});

	
//form validation code
function validateForm(){
	//checking for name field for empty, undefined, null
	var name = !$("#name").val() || $("#name").val()== undefined || $("#name").val()== "undefined" || $("#name").val()== null || $("#name").val()=="null";
	//checking for category field for empty, undefined, null
	var category = !$("#category").val() || $("#category").val()== undefined || $("#category").val()== "undefined" || $("#category").val()== null || $("#category").val()=="null";
	//checking for price field for empty, undefined, null
	var price = !$("#price").val() || $("#price").val()== undefined || $("#price").val()== "undefined" || $("#price").val()== null || $("#price").val()=="null";
	//checking for description field for empty, undefined, null
	var description = !$("#description").val() || $("#description").val()== undefined || $("#description").val()== "undefined" || $("#description").val()== null || $("#description").val()=="null";
	
	return name || category || price || description;
}

//Get List of Products from the database
function getProducts() {	
	 $.ajax({
			 url: 'http://localhost:3000/products',
			 type: 'GET',
			 dataType: 'json',
			 success: function (data, textStatus, xhr) {
				if(data.status == "success" && data.code == 200){
					productList = data.data;					
					populateProducts(productList, categoryFilterList, searchText);					
					buildCategoriesList(productList);
				}else{
					$("#messageDiv").css('background-color', '#d9534f');
					$("#messageDiv").find("h5").text(data.error);
					$("#messageDiv").show();
					setTimeout(function(){ $("#messageDiv").hide() }, 5000);
				}			 
			 },
			 error: function (xhr, textStatus, errorThrown) {
				$("#messageDiv").css('background-color', '#d9534f');
				$("#messageDiv").find("h5").text("Error in while calling the get products.");
				$("#messageDiv").show();
				setTimeout(function(){ $("#messageDiv").hide() }, 5000);
			 }	
		});
	//End of the ajax call	
}


//common code function to view products list based on category filters, search text and nothing. 
function populateProducts(productList, categoryFilterList, searchText){
	$('#productTable').empty();
		
	//if category filter and search text are empty, then showing all the product list.
	if(categoryFilterList.length == 0 && !searchText.trim()){
		$.each(productList, function (i, item) {						
			buildProducts(item);
		});
	}
	//if category filter is not empty, search text is empty then filtering product list based on category and displaying it.
	else if(categoryFilterList.length != 0 && !searchText.trim()){
		$.each(productList, function (i, item) {	
			$.each(categoryFilterList, function(index, categoryValue){
				if(categoryValue.toLowerCase() == item.category.toLowerCase()){
					buildProducts(item);
				}
			});					
		});
	}
	//if search text is not empty then filtering product list based on search text and displaying it.
	else{
		$.each(productList, function (i, item) {
			searchText = searchText.toString().toLowerCase();
			var name = item.name.toString().toLowerCase();
			var description = item.description.toString().toLowerCase();
			var category = item.category.toString().toLowerCase();
			var price = item.price.toString();
			if(name.indexOf(searchText) > -1 || description.indexOf(searchText) > -1 || category.indexOf(searchText)> -1 || price.indexOf(searchText)> -1){
				buildProducts(item);
			}								
		});
	}
}

function buildProducts(item){
	var image_src = "";
	if(item.hasOwnProperty("productImg")){
		image_src = item.productImg.filePath.toString().replace("./public", "..");
	}else{
		image_src = "../images/Product/"+item._id+"_Product.png";
	}
	
	var buttonR= "<input type='submit' value='Remove'>";
	var buttonE= "<input type='submit' value='Edit'>";
	var content = "";
	var btnControl = "";
	var uploadIcon = "";
	var trHTML = "";
	
	/*dynamic inner HTML to show the products*/
	trHTML += "<table style='margin-bottom:0px;width: 98%;' class='table'>";
	//Product Image section
	trHTML += "<tr style='border: 1px solid #E6E6E6;border-bottom:none;height:150px;'>";
	trHTML += "<td style='padding: 25px 65px;width: 30%;'>";
	trHTML += "<div class='image-upload'>";
	trHTML += "<label for='"+item._id+"'><img src='"+image_src+"?v=" + new Date().getTime()+"'/></label>";
	trHTML += "<input id='"+item._id+"' onchange='selectImg()' type='file' multiple='multiple' style='display:none;'/><div id='image-holder'></div>";
	trHTML += "</div><br />";
	trHTML += "<div class='col-md-6 col-sm-6 col-xs-6' id="+item._id+ " onclick='uploadImage()' style='margin-top:-10%;float:right;cursor:pointer;padding: 0px;'><i style='margin-right:5px;'class='fa fa-upload' aria-hidden='true'>";
	trHTML += "<input type='file' id='imgupload' style='display:none'/></i>Upload</div>";
	trHTML += "</td>";
	//Product info section(Name, Description, Category, Price)
	trHTML += "<td colspan='4'>";
	trHTML += "<div style='float:left;margin-top:20px;'><div><h1>"+item.name+"</h1></div>";
	trHTML += "<div><h5>"+item.description +"</h5></div>";
	trHTML += "<div><span style='color:#fff;background-color:grey;padding: 4px;font-size: small;border-radius: 2px;'><b><i>"+item.category+"</i></b></span></div>";
	trHTML += "<div><span style='color:red;'><h1><i>Rs:"+item.price+"</i></h1></span></div>"
	trHTML += "</td>";
	trHTML += "</tr>";
	//Button control section
	trHTML += "<tr style='border: 1px solid #E6E6E6;border-top:2px solid #E6E9ED;background-color: #F1F5F8;'>";
	trHTML += "<td colspan='2' style='border: 1px solid  #ddd;'>"
	trHTML += "<div style='margin-right: 110px;padding-top: 5px;float:right;'>";
	trHTML += "<button type='button' id="+item._id+ " onclick='remove()' style='background-color:#d9534f;border-color:#d9534f;position:inherit;' class='btn btn-primary'>";
	trHTML += "<i style='padding-right:5px' class='fa fa-trash'></i>Remove</button>";
	trHTML += "<button type='button' id="+item._id+ " onclick='edit()' style='background-color:#26b99a;border-color:#26b99a;margin-left:10px;' class='btn btn-primary'>";
	trHTML += "<i style='padding-right:5px' id="+item._id+ " class='fa fa-pencil-square-o'></i>Edit</button></div>";
	trHTML += "</td>";
	trHTML += "</tr>";
	trHTML += "</table><br><br>";
    $('#productTable').append(trHTML);	
}

//To reset the form values when cancel clicked or once the call is success and setting back to Add mode.
function emptyForm(){
	$("#name").val('');
	$("#category").val('');
	$("#price").val('');
	$("#description").val('');
	$("#formMessage").hide();
	$("#addProduct").css("display","block");
	$("#editProduct").css("display","none");
	$("#submit").show();
	$(".update").hide();
}


//Code to show the pop-up for user confirmation regarding deletion of product and closing wherever user clicks on window other than modal.
function remove(){
	var productId = event.target.id;
	
// Get the modal and open it.
var modal = document.getElementById('myModal');
modal.style.display = "block";

$("#myModal #remove").attr('item', productId);

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];


// When the user clicks on <span> (x), close the modal
span.onclick = function() {
    modal.style.display = "none";
	$("#myModal #remove").removeAttr('item');
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
		$("#myModal #remove").removeAttr('item');
    }
}
}


/*Remove Product*/
function removeProduct(id) {
	
	$.ajax({  
            type: "DELETE",  
            url: "http://localhost:3000/product/"+id,  
            data: '',  
            success: function(data) {
				if(data.status == "success" && data.code == 200){
					getProducts();
					emptyForm();
					removeCategory();
					$("#messageDiv").css('background-color', 'rgb(38,187,157)');
					$("#messageDiv").find("h5").text("Successfully Removed");
					$("#messageDiv").show();
					setTimeout(function(){ $("#messageDiv").hide() }, 5000);
				}else{
					$("#messageDiv").css('background-color', '#d9534f');
					$("#messageDiv").find("h5").text(data.error);
					$("#messageDiv").show();
					setTimeout(function(){ $("#messageDiv").hide() }, 5000);
				}                 
            },
			 error: function (xhr, textStatus, errorThrown) {
				$("#messageDiv").css('background-color', '#d9534f');
				$("#messageDiv").find("h5").text("Error in operation");
				$("#messageDiv").show();
				setTimeout(function(){ $("#messageDiv").hide() }, 5000);
			 }  
    });

}

//Code to populate the information in the form when edit button clicked.
function edit(){
	var productId = event.target.id;
	$.each(productList, function(index, item){
		if(productId.toString() == item._id.toString()){
			//populating the info of product, to edit. 
			$("#name").val(item.name);
			$("#category").val(item.category);
			$("#price").val(item.price);
			$("#description").val(item.description);
			
			//disbale add product
			$("#addProduct").css("display","none");
			$("#submit").hide();
			
			//enable edit product
			$("#editProduct").css("display","block");
			$(".update").show();
			$(".update").attr('id', productId);
		}
	});
}



/*Update Product*/
function editProduct(id) {
    var name = $("#name").val();
	var category = $("#category").val();
	var price = $("#price").val();
	var description = $("#description").val();
	var dataString = 'name='+ name + '&category=' + category + '&price=' + price+ '&description='+ description;
	$.ajax({  
            type: "PUT",  
            url: "http://localhost:3000/product/"+id,  
            data: dataString,  
            success: function(data) {
				if(data.status == "success" && data.code == 200){
					getProducts();
					emptyForm();
					$("#addProduct").css("display","block");
					$("#submit").show();
					$("#editProduct").css("display","none");
					$(".update").hide();
					$("#formMessage").css('background-color', '#26b99a');
					$("#formMessage").find("h5").text("Successfully Updated");
					$("#formMessage").show();
					setTimeout(function(){ $("#formMessage").hide() }, 5000);
				}else{
					$("#formMessage").css('background-color', '#d9534f');
					$("#formMessage").find("h5").text(data.error);
					$("#formMessage").show();
					setTimeout(function(){ $("#formMessage").hide() }, 5000);
				}                 
            },
			 error: function (xhr, textStatus, errorThrown) {
				$("#formMessage").css('background-color', '#d9534f');
				$("#formMessage").find("h5").text("Error in operation.");
				$("#formMessage").show();
				setTimeout(function(){ $("#formMessage").hide() }, 5000);
			 }  
    }); 
}




//Code to create Product.
function createProduct() {

    var name = $("#name").val();
	var category = $("#category").val();
	var price = $("#price").val();
	var description = $("#description").val();
	var dataString = 'name='+ name + '&category=' + category + '&price=' + price+ '&description='+ description;
	
	$.ajax({  
            type: "POST",  
            url: "http://localhost:3000/product/",  
            data: dataString,  
            success: function(data) {
				if(data.status == "success" && data.code == 200){
					getProducts();
					emptyForm();
					$("#formMessage").css('background-color', '#26b99a');
					$("#formMessage").find("h5").text("Product Successfully Saved");
					$("#formMessage").show();
					setTimeout(function(){ $("#formMessage").hide() }, 5000);
				}else{
					$("#formMessage").css('background-color', '#d9534f');
					$("#formMessage").find("h5").text(data.error);
					$("#formMessage").show();
					setTimeout(function(){ $("#formMessage").hide() }, 5000);
				}               
            },
			 error: function (xhr, textStatus, errorThrown) {
				$("#formMessage").css('background-color', '#d9534f');
				$("#formMessage").find("h5").text("Error in operation.");
				$("#formMessage").show();
				setTimeout(function(){ $("#formMessage").hide() }, 5000);
			 }  
        }); 

}



//Code Block for Drag and Drop Filter
// Starting code for making the Category List
function buildCategoriesList(productList){
	$("#allcategories").empty();
	categoryList =[];
	//getting the category from the product list.
	$.each(productList, function(index, item){
		var category = item.category.charAt(0).toUpperCase() + item.category.slice(1);
		categoryList.push(category);
	});
	//remove the duplicate category list and capitalize the first letter of the String in array .
	categoryList = jQuery.unique(categoryList);
	
	//sorting the category list based on alphabet
	categoryList.sort();
	
	//build html code for category list
	$.each(categoryList, function(index, item){
		var category = '<div itemid="itm-'+index+'" draggable="true" class="btn btn-default category-item" style="background-color:rgb(38,187,157);color:white;">'+item+'</div>';
		$("#allcategories").append(category);
	});
	drapAndDrop();
}
// Ending code for making the Category List


    
//Code here for filtering the products list on Drop
function drapAndDrop(){
	$(".category-item").draggable({
		appendTo: '#allcategories',
		revert: true,// bounce back when dropped
		cursor: 'move',
		helper: "clone",// create "copy" with original properties, but not a true clone		
		revertDuration: 0 // immediate snap
	});
	
	$("#category-filter").droppable({
		accept: ".category-item",
		  drop: function(event, ui) {
				var itemid = $(event.originalEvent.toElement).attr("itemid");
				var count=0;
				var duplicateCount = 0;
				//Checking whether I already dragged the dragging item to avoid duplicate filter.
				$('#category-filter').find(".category-item").each(function() {	
					if ($(this).attr("itemid") === itemid) {
						++duplicateCount;
					}
				});
		
				$('.category-item').each(function() {			
				  if ($(this).attr("itemid") === itemid) {					
					if(count == 0 && duplicateCount==0){
						var $item = ui.draggable.clone();
						categoryFilterList.push($(this).text());
						$item.removeClass('ui-draggable ui-draggable-dragging resize-drag').addClass('dropped-element');
						//adding the remove button to the category button.
						$item.appendTo("#category-filter").after('<span onclick="removeCategory()" class="fa-stack closeBox"><i class="fa fa-times fa-stack-1x whiteClose" id="'+itemid+'" aria-hidden="true"></i></span>');
						$("#searchText").val("");//empty the search text.
						searchText = "";//empty the search text.
						populateProducts(productList, categoryFilterList, searchText);
					}
					++count;
				  }
				});
			}		
	});
}


//Code to remove a category from the filter list
function removeCategory(){
	var itemid = event.target.id;
	//removing category from category filter
	$('#category-filter').find(".category-item").each(function() {	
		if ($(this).attr("itemid") === itemid) {
			categoryFilterList.splice($.inArray($(this).text(), categoryFilterList), 1);
			$(this).next("span").remove();
			$(this).remove();
			$("#searchText").val("");//empty the search text.
			searchText = "";//empty the search text.
			populateProducts(productList, categoryFilterList, searchText);
		}
	});
}

	
	
//Code block for Free Text Search
$(document).ready(function() {
    $("#searchText").keyup(function() {
		searchText = "";
		searchText = $("#searchText").val().toLowerCase();
		if(searchText.trim()){
			//removing all the categories from category filter nav bar.
			$("#category-filter").empty();
			categoryFilterList =[];
			populateProducts(productList, categoryFilterList, searchText);
		}else{
			populateProducts(productList, categoryFilterList, searchText);
		}
    });

});


//Code for Image select and preview it.
function selectImg(){
	var productId = event.target.id;
	var thisDomElement = $("#"+productId+"");
	
        if (typeof (FileReader) != "undefined") {
			var previousImg = $(thisDomElement).prev("label").find("img").attr("src");
            var dvPreview = $(thisDomElement).prev("label");
            dvPreview.html("");
            var regex = /^([a-zA-Z0-9\s_\\.\-:])+(.jpg|.jpeg|.gif|.png|.bmp)$/;
            $($(thisDomElement)[0].files).each(function () {
                var file = $(this);
                if (regex.test(file[0].name.toLowerCase())) {
                    var reader = new FileReader();
                    reader.onload = function (e) {
                        var img = $("<img />");
                        img.attr("src", e.target.result);
                        dvPreview.append(img);
                    }
                    reader.readAsDataURL(file[0]);
                } else {
                    $("#messageDiv").css('background-color', '#d9534f');
					$("#messageDiv").find("h5").text("Click on an image to select a new file");
					$("#messageDiv").show();
					setTimeout(function(){ $("#messageDiv").hide() }, 5000);
                    var img = $("<img />");                        
                        img.attr("src", previousImg);
                        dvPreview.append(img);
                    return false;
                }
            });
        } else {
			$("#messageDiv").css('background-color', '#d9534f');
			$("#messageDiv").find("h5").text("This browser does not support HTML5 FileReader.");
			$("#messageDiv").show();
			setTimeout(function(){ $("#messageDiv").hide() }, 5000);
        }
}

//Code to form FormData and to call the update the image call.
function uploadImage(){
	var productId = event.target.id;
	var thisDomElement = $("#"+productId+"");
	console.log($(thisDomElement)[0].files);
	var file_data = $(thisDomElement)[0].files[0];// Getting the properties of file from file field
	if(file_data == undefined || file_data == "undefined" || file_data == null || file_data == "null" || file_data==""){
		$("#messageDiv").css('background-color', '#d9534f');
		$("#messageDiv").find("h5").text("Click on an image to select a new file");
		$("#messageDiv").show();
		setTimeout(function(){ $("#messageDiv").hide() }, 5000);
	}else{
		var form_data = new FormData();
		form_data.append('file', file_data, file_data.name);// Appending parameter named file with properties of file_field to form_data	
	
		jQuery.ajax({  
			type: "PUT",  
			url: "http://localhost:3000/product/"+productId+"/ProductImg",
			contentType: false,
			processData: false,	
			cache: false,
			data: form_data,  
			success:function(response){
				if(response.status == "success" && response.code == 200){	
					getProducts();
					$("#messageDiv").css('background-color', '#26b99a');
					$("#messageDiv").find("h5").text("Image successfully Updated");
					$("#messageDiv").show();
					setTimeout(function(){ $("#messageDiv").hide() }, 5000);
				}else{
					$("#messageDiv").css('background-color', '#d9534f');
					$("#messageDiv").find("h5").text(response.error);
					$("#messageDiv").show();
					setTimeout(function(){ $("#messageDiv").hide() }, 5000);
				}
			},
			error:function (xhr, textStatus, errorThrown){
				$("#messageDiv").css('background-color', '#d9534f');
				$("#messageDiv").find("h5").text("Error in operation.");
				$("#messageDiv").show();
				setTimeout(function(){ $("#messageDiv").hide() }, 5000);
			}
		}); 
	}
}
